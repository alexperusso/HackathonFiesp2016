#ifndef INICIALIZATIONSINGLETON_H
#define INICIALIZATIONSINGLETON_H

#include "integra.h"

Integra *Integra::instance = NULL;

#endif // INICIALIZATIONSINGLETON_H
