#include "device.h"

Device::Device()
{

}

int Device::getId()
{
    return this->id;
}

QString Device::getName() const
{
    return this->name;
}

QString Device::getUserName()
{
    return this->username;
}

QString Device::getPass()
{
    return this->pass;
}

QString Device::getChannelIn()
{
    return this->channelin;
}

QString Device::getChannelOut()
{
    return this->channelout;
}

bool Device::getStatus() const
{
    return this->status;
}

int Device::getType() const
{
    return this->getType();
}

void Device::setId(int value)
{
    this->id = value;
}

void Device::setName(QString value)
{
    this->name = value;
}

void Device::setUserName(QString value)
{
    this->username = value;
}

void Device::setPass(QString value)
{
    this->pass = value;
}

void Device::setChannelIn(QString value)
{
    this->channelin = value;
}

void Device::setChannelOut(QString value)
{
    this->channelout = value;
}

void Device::setStatus(bool value)
{
    this->status = value;
}

void Device::setType(TypeDevice value)
{
    this->type = value;
}

void Device::setType(int value)
{
    this->type = (TypeDevice)value;
}

bool Device::turnOn()
{
    AcessWSRest acess;
    acess.setPass(this->getPass());
    acess.setUserName(this->getUserName());
    acess.setUrl(QString("https://api.hackathon.konkerlabs.net/pub/%1/%2").arg(this->getUserName()).arg(this->getChannelIn()));
    qDebug()<<QString("https://api.hackathon.konkerlabs.net/pub/%1/%2").arg(this->getUserName()).arg(this->getChannelIn());
    QString msg("{\"pin\": \"%1\", \"val\": %2}");
    return acess.post(msg.arg(this->getId()).arg(DEVICE_ACTIVE));
}

bool Device::turnOff()
{
    AcessWSRest acess;
    acess.setPass(this->getPass());
    acess.setUserName(this->getUserName());
    acess.setUrl(QString("https://api.hackathon.konkerlabs.net/pub/%1/%2").arg(this->getUserName()).arg(this->getChannelIn()));
    QString msg("{\"pin\": \"%1\", \"val\": %2}");
    return acess.post(msg.arg(this->getId()).arg(DEVICE_DESACTIVE));
}

bool Device::getDeviceState()
{
    AcessWSRest acess;
    acess.setPass(this->getPass());
    acess.setUserName(this->getUserName());
    acess.setUrl(QString("https://api.hackathon.konkerlabs.net/pub/%1/%2").arg(this->getUserName()).arg(this->getChannelIn()));
    QString msg("{\"pin\": \"%1\", \"val\": %2}");
    acess.post(msg.arg(this->getId()).arg(DEVICE_QUERY));

    acess.setPass(this->getPass());
    acess.setUserName(this->getUserName());
    acess.setUrl(QString("https://api.hackathon.konkerlabs.net/sub/%1/%2").arg(this->getUserName()).arg(this->getChannelOut()));
    QString msgrequest = acess.request();
    QJsonDocument jsonResponse = QJsonDocument::fromJson(msgrequest.toUtf8());
    QJsonArray jsonarray = jsonResponse.array();
    for(const QJsonValue &value : jsonarray)
    {
        QJsonObject obj = value.toObject();

        if (obj["data"].toObject().value("val").toInt() == DEVICE_ACTIVE)
            this->setStatus(true);
        else
            this->setStatus(false);
    }
}

DeviceModel::DeviceModel(QObject *parent)
{
    Q_UNUSED(parent);
    this->devices = new QList<Device*>();
}

DeviceModel::~DeviceModel()
{
    delete(this->devices);
}

void DeviceModel::addDevice(Device *value)
{
    beginInsertRows(QModelIndex(), rowCount(), rowCount());
    this->devices->append(value);
    endInsertRows();
}

int DeviceModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return this->devices->count();
}

QVariant DeviceModel::data(const QModelIndex &index, int role) const
{
    if (index.row() < 0 || index.row() >= this->devices->count())
        return QVariant();

    const Device *device = this->devices->at(index.row());
    switch (role) {
    case TypeRole:
        switch (device->getType()) {
        case KITCHEN :
            return QString("Cozinhas");
            break;
        case BATHROOM:
            return QString("Banhos");
            break;
        case ROOM:
            return QString("Quartos");
            break;
        case HALL:
            return QString("Corredores");
            break;
        case GARDEN:
            return QString("Jardins");
            break;
        case GARAGE:
            return QString("Garagem");
            break;
        case TERRACE:
            return QString("Varanda");
            break;
        default:
            return QString("None");
            break;
        }
        break;
    case NameRole:
        return device->getName();
        break;
    case StatusRole:
        return  device->getStatus();
    default:
        break;
    }
    return QVariant();
}

void DeviceModel::clear()
{
    beginResetModel();

    this->devices->clear();

    qDeleteAll(*this->devices);

    endResetModel();
}

QHash<int, QByteArray> DeviceModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[TypeRole] = "type";
    roles[StatusRole] = "status";
    roles[NameRole] = "name";
    return roles;
}
