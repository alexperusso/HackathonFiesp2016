#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "inicializationsingleton.h"
#include "device.h"
#include "integra.h"

int main(int argc, char *argv[])
{
    qmlRegisterType<Device>("integra.device", 1, 0, "Device");
    qmlRegisterSingletonType<Integra>("integra.api", 1, 0, "Integra", &Integra::getQmlInstance);

    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    engine.load(QUrl(QLatin1String("qrc:/main.qml")));

    Integra::getInstance()->setEngineQml(engine);

    Device device;
    device.setId(0);
    device.setChannelIn("rx");
    device.setChannelOut("tx");
    device.setUserName("9v225cg4n6il");
    device.setPass("heB7EmD3A5Yi");
    device.turnOn();
//    device.turnOff();
//    device.getDeviceState();

    return app.exec();
}
