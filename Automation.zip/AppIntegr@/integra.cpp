#include "integra.h"

Integra::Integra()
{
    this->modeldevices = new DeviceModel();
}

Integra::~Integra()
{
    delete(modeldevices);
}

void Integra::setEngineQml(QQmlApplicationEngine &value)
{
    this->engine = &value;
}

QObject *Integra::getQmlInstance(QQmlEngine *engine, QJSEngine *scriptEngine)
{
    Q_UNUSED(engine);
    Q_UNUSED(scriptEngine);

    return getInstance();
}

Integra *Integra::getInstance()
{
    if(!instance)
        instance = new Integra();
    return instance;
}

void Integra::showDevices()
{
    this->modeldevices->clear();

    Device *dev1 = new Device();
    dev1->setChannelIn("in");
    dev1->setChannelOut("out");
    dev1->setName("Luz da Cozinha 1");
    dev1->setUserName("erm2jncfr7bg");
    dev1->setPass("VqASt64cIEGb");
    dev1->setStatus(false);

    Device *dev2 = new Device();
    dev2->setChannelIn("in");
    dev2->setChannelOut("out");
    dev2->setName("Luz da Cozinha 2");
    dev2->setUserName("erm2jncfr7bg");
    dev2->setPass("VqASt64cIEGb");
    dev2->setStatus(false);

    Device *dev3 = new Device();
    dev3->setChannelIn("in");
    dev3->setChannelOut("out");
    dev3->setName("Luz da Cozinha 3");
    dev3->setUserName("erm2jncfr7bg");
    dev3->setPass("VqASt64cIEGb");
    dev3->setStatus(false);

    Device *dev4 = new Device();
    dev4->setChannelIn("in");
    dev4->setChannelOut("out");
    dev4->setName("Luz da Cozinha 4");
    dev4->setUserName("erm2jncfr7bg");
    dev4->setPass("VqASt64cIEGb");
    dev4->setStatus(false);

    Device *dev5 = new Device();
    dev5->setChannelIn("in");
    dev5->setChannelOut("out");
    dev5->setName("Luz da Cozinha 5");
    dev5->setUserName("erm2jncfr7bg");
    dev5->setPass("VqASt64cIEGb");
    dev5->setStatus(false);

    this->modeldevices->addDevice(dev1);
    this->modeldevices->addDevice(dev2);
    this->modeldevices->addDevice(dev3);
    this->modeldevices->addDevice(dev4);
    this->modeldevices->addDevice(dev5);

    QQmlContext *ctxt = this->engine->rootContext();

    ctxt->setContextProperty("modelDevice", this->modeldevices);
}
