#include "acesswsrest.h"

QByteArray AcessWSRest::getAuth()
{
    QString concatenated = this->getUserName() + ":" + this->getPass();
    QByteArray data = concatenated.toLocal8Bit().toBase64();
    QString headerData = "Basic " + data;
    return headerData.toLocal8Bit();
}

AcessWSRest::AcessWSRest()
{

}

QString AcessWSRest::request()
{
    QNetworkAccessManager mgr;

    QEventLoop eventLoop;
    QObject::connect(&mgr, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));

    QNetworkRequest req(QUrl(this->getUrl()));

    req.setRawHeader("Authorization", this->getAuth());
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QNetworkReply *reply = mgr.get(req);

    eventLoop.exec();

    if (reply->error() == QNetworkReply::NoError) {                
        delete reply;
        return QString(reply->readAll());
    }
    else {
        qDebug() << "Failure" <<reply->errorString();
        delete reply;
        return QString();
    }
}

bool AcessWSRest::post(QString value)
{
    QNetworkAccessManager mgr;
    QEventLoop eventLoop;
    QObject::connect(&mgr, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));

    QNetworkRequest req(QUrl(this->getUrl()));

    req.setRawHeader("Authorization", this->getAuth());
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QNetworkReply *reply = mgr.post(req, value.toLocal8Bit());

    eventLoop.exec();

    if (reply->error() == QNetworkReply::NoError) {
        QString strReply = QString(reply->readAll());
        delete reply;
        QJsonDocument jsonResponse = QJsonDocument::fromJson(strReply.toUtf8());
        QJsonObject jsonObj = jsonResponse.object();
        qDebug() << "Message: " << jsonObj.value(QString("message")).toString();
        qDebug() << "Code: " << jsonObj.value(QString("code")).toString();

        if(jsonObj.value(QString("code")).toInt() == 200)
            return true;
        else
            return false;
    }
    else {
        qDebug() << "Failure" <<reply->errorString();
        delete reply;
        return false;
    }
}

void AcessWSRest::setPass(QString value)
{
    this->pass = value;
}

void AcessWSRest::setUserName(QString value)
{
    this->username = value;
}

void AcessWSRest::setUrl(QString value)
{
    this->url = value;
}

QString AcessWSRest::getUrl()
{
    return this->url;
}

QString AcessWSRest::getPass()
{
    return this->pass;
}

QString AcessWSRest::getUserName()
{
    return this->username;
}
