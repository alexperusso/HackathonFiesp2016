#ifndef DEVICE_H
#define DEVICE_H

#include <QObject>
#include <QAbstractListModel>
#include "acesswsrest.h"

#define DEVICE_DESACTIVE 0
#define DEVICE_ACTIVE 1
#define DEVICE_QUERY 2

enum TypeDevice{
    KITCHEN, BATHROOM, ROOM, HALL, GARDEN, GARAGE, TERRACE
};

class Device : public QObject
{
    Q_OBJECT
protected:
    int id;
    QString name, username, pass, channelin, channelout;
    bool status;
    TypeDevice type;
public:
    Device();
    int getId();
    QString getName() const;
    QString getUserName();
    QString getPass();
    QString getChannelIn();
    QString getChannelOut();
    bool getStatus() const;
    int getType() const;

    void setId(int value);
    void setName(QString value);
    void setUserName(QString value);
    void setPass(QString value);
    void setChannelIn(QString value);
    void setChannelOut(QString value);
    void setStatus(bool value);
    void setType(TypeDevice value);
    void setType(int value);

    Q_INVOKABLE bool turnOn();
    Q_INVOKABLE bool turnOff();
    Q_INVOKABLE  bool getDeviceState();
};

class DeviceModel : public QAbstractListModel
{
    Q_OBJECT
public:
    enum DeviceRoles {
        TypeRole = Qt::UserRole + 1, NameRole, StatusRole
    };
    DeviceModel(QObject *parent = 0);
    ~DeviceModel();
    void addDevice(Device *value);
    int rowCount(const QModelIndex & parent = QModelIndex()) const;
    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;
    void clear();
protected:
    QHash<int, QByteArray> roleNames() const;    
private:
    QList<Device*> *devices;
};

#endif // DEVICE_H
