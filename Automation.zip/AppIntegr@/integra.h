#ifndef INTEGRA_H
#define INTEGRA_H

#include <QObject>
#include <QtQml>
#include "device.h"

class Integra : public QObject
{
    Q_OBJECT
protected:
    static Integra *instance;//save instance of Sigleton
    QQmlApplicationEngine *engine;

    DeviceModel *modeldevices;

public:
    Integra();
    ~Integra();

    void setEngineQml(QQmlApplicationEngine &value);

    //Static methods
    static QObject *getQmlInstance(QQmlEngine *engine, QJSEngine *scriptEngine);
    static Integra *getInstance();//get instance of Sigleton

    Q_INVOKABLE void showDevices();
};

#endif // INTEGRA_H
