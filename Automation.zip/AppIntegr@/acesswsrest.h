#ifndef ACESSWSREST_H
#define ACESSWSREST_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QMap>
#include <QtNetwork/QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonObject>
#include <QEventLoop>

class AcessWSRest
{
protected:
    QString pass, username, url;
    QByteArray getAuth();
public:
    AcessWSRest();
    QString request();
    bool post(QString value);
    void setPass(QString value);
    void setUserName(QString value);
    void setUrl(QString value);
    QString getUrl();
    QString getPass();
    QString getUserName();
};

#endif // ACESSWSREST_H
